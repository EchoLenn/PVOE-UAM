# Importa el módulo random para generar valores aleatorios
import random

# Importa la clase base abstracta Pelota
from pelota import Pelota

# Define la clase PelotaNumero que hereda de Pelota
class PelotaNumero(Pelota):

    # Constructor: inicializa la clase base y define el atributo específico 'numero'
    def __init__(self, identificador, participante):
        super().__init__(identificador, participante)  # Llama al constructor de Pelota
        self.__numero = 0  # Valor numérico inicial de la pelota

    # Genera un número aleatorio entre 1 y 4 y lo asigna al atributo 'numero'
    def generarValor(self):
        self.__numero = random.randint(1, 4)

    # Asigna aleatoriamente un color a la pelota desde una lista predefinida
    def pintarPelota(self):
        self.color = random.choice(['amarillo', 'morado', 'rosa'])

    # Getter para acceder al número generado de forma segura
    @property
    def numero(self):
        return self.__numero

    # Cadena de texto con formato
    def __str__(self):
        return (f"Identificador: {self.identificador} \t\tParticipante: {self.participante}\n"
                f"\tColor: {self.color} \t\tNúmero: {self.numero}")

