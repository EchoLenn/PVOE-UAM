# Importa el módulo random para seleccionar letras y colores aleatorios
import random

# Importa la clase base abstracta Pelota
from pelota import Pelota

# Define la clase PelotaLetra que hereda de Pelota
class PelotaLetra(Pelota):

    # Constructor: inicializa con el identificador, participante y define letra por defecto
    def __init__(self, identificador, participante):
        super().__init__(identificador, participante)  # Llama al constructor de la clase base
        self.__letra = 'X'  # Valor por defecto hasta que se genere uno real

    # Método que genera una letra aleatoria entre A, B, C y D (categoría del premio)
    def generarValor(self):
        self.__letra = random.choice(['A', 'B', 'C', 'D'])

    # Asigna aleatoriamente un color entre azul, verde y rojo (usado para definir la unidad)
    def pintarPelota(self):
        self.color = random.choice(['azul', 'verde', 'rojo'])

    # Getter para acceder a la letra generada
    @property
    def letra(self):
        return self.__letra

    # Método especial que define cómo se imprime una instancia de PelotaLetra
    def __str__(self):
        return (f"Identificador: {self.identificador} \t\tParticipante: {self.participante}\n"
                f"\tColor: {self.color} \t\tLetra: {self.letra}")
