# Importa las clases PelotaNumero y PelotaLetra desde módulos separados
from pelota_numero import PelotaNumero
from pelota_letra import PelotaLetra

# Función que interpreta los atributos de las pelotas y asigna un premio en base a ellos
def decifrarPremio(pelota_numero, pelota_letra):
    # Determina la unidad en base al color de la pelota_letra
    unidad = {
        "azul": "Xochimilco",
        "verde": "Iztapalapa",
        "rojo": "Azcapotzalco"
    }.get(pelota_letra.color, "Desconocida")  # Si el color no está definido, se marca como desconocida

    # Determina la categoría del premio en base a la letra obtenida
    categoria = {
        "A": "Libros físicos",
        "B": "Libros electrónicos",
        "C": "Papelería",
        "D": "Souvenirs"
    }.get(pelota_letra.letra, "Desconocida")

    # Asigna la cantidad económica del premio según el color de la pelota_numero
    cantidad = {
        "amarillo": "$1000",
        "morado": "$2000",
        "rosa": "$3000"
    }.get(pelota_numero.color, "Desconocida")

    # Establece la vigencia del premio en meses, basándose en el número de la pelota
    vigencia = f"{pelota_numero.numero} mes{'es' if pelota_numero.numero > 1 else ''}"

    # Retorna toda la información del premio
    return unidad, categoria, cantidad, vigencia

# Función principal que ejecuta todo el proceso de asignación de premios
def main():
    # Lista de participantes: tuplas con identificador y nombre
    participantes = [
        (10, "Daniel Hernández"),
        (14, "Patricia García"),
        (20, "Cristina Rodríguez"),
        (34, "Agustin Rivera")
    ]
    #maneja errores que pueden ocurrir durante la ejecucion del programa
    try:
        # Abre el archivo de salida para guardar los premios (modo agregar y leer)
        with open("premios.txt", "a+", encoding="utf-8") as archivo:
            # Recorre todos los participantes
            for id_part, nombre in participantes:
                # Se crean los objetos de pelota para número y letra con el ID y nombre del participante
                pelota_num = PelotaNumero(id_part, nombre)
                pelota_let = PelotaLetra(id_part, nombre)

                # Genera valores aleatorios para la pelota numérica y visualiza su información
                pelota_num.generarValor()
                pelota_num.pintarPelota()

                #Llama al metodo
                # Genera valores aleatorios para la pelota de letra y visualiza su información
                pelota_let.generarValor()
                pelota_let.pintarPelota()

                # Decodifica el premio a partir de los valores generados en ambas pelotas
                unidad, categoria, cantidad, vigencia = decifrarPremio(pelota_num, pelota_let)

                # Construye la cadena con la información del premio para guardar en el archivo
                resultadoo = (
                    f"\nIdentificador: {id_part}  Participante: {nombre}\n"
                    f"  Unidad: {unidad}\n"
                    f"  Categoría: {categoria}\n"
                    f"  Cantidad: {cantidad}\n"
                    f"  Vigencia: {vigencia}\n"
                    f"{'-' * 40}"
                )

                # Construye el texto con la representación visual de las pelotas (para consola)
                resultado = (
                    f" {pelota_num}\n"
                    f" {pelota_let}\n"
                )

                # Imprime en consola la información generada
                print(resultado)

                # Escribe el resultado en el archivo de premios
                archivo.write(resultadoo + "\n")

    # Captura si el archivo no se encuentra (por ejemplo, ruta incorrecta)
    except FileNotFoundError:
        print("Error: Archivo de participantes no encontrado.")

    # Siempre se ejecuta al final, ocurra o no un error
    finally:
        print("Proceso finalizado.")

# Llama a la función main solo si este archivo es ejecutado directamente
if __name__ == "__main__":
    main()
