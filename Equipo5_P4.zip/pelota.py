# Importa clases base abstractas desde el módulo abc (Abstract Base Classes)
from abc import ABC, abstractmethod

# Definición de la clase abstracta 'Pelota', que no puede ser instanciada directamente
class Pelota(ABC):

    # Constructor de la clase base. Inicializa los atributos comunes
    def __init__(self, identificador, participante):
        self.__identificador = identificador  # ID único del participante
        self.__participante = participante    # Nombre del participante
        self.__color = "blanco"               # Color inicial por defecto

    # Método que define cómo se "pinta" la pelota
    @abstractmethod
    def pintarPelota(self):
        pass

    # Método que genera el valor asociado a la pelota
    @abstractmethod
    def generarValor(self):
        pass

    # Getter para acceder al identificador
    @property
    def identificador(self):
        return self.__identificador

    # Getter para acceder al nombre del participante
    @property
    def participante(self):
        return self.__participante

    # Getter para acceder al color de la pelota
    @property
    def color(self):
        return self.__color

    # Setter para modificar el color de la pelota
    @color.setter
    def color(self, color):
        self.__color = color

    # Formato de impresion de la cadena de texto
    def __str__(self):
        return (f"ID: {self.identificador}, Participante: {self.participante}, Color: {self.color}")
